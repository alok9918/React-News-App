#include <iostream>
#include<fstream>
using namespace std;
class icecream
{
protected:
    int quantity;
    char icecream_name[10];
    char flavour[20];
    int a,b,t,i,j;
    public:
    void detail()
    {
    	
ofstream f("icecreamparlor.txt",ios::out);
cout<<"SrNo.   Flavour                                      Rate"<<endl;
cout<<endl;
cout<<"1       Vanila                                        110"<<endl;
cout<<"2       Fresh Strawberry                              160"<<endl;
cout<<"3       Fresh Orange                                  110"<<endl;
cout<<"4       Mangoo Ripple                                 140"<<endl;
cout<<"5       Chocolate Ripple                              140"<<endl;
cout<<"6       Gulab Kaaju                                   110"<<endl;
cout<<"7       Black Current                                 160"<<endl;
cout<<"8       American Nuts                                 150"<<endl;
cout<<"9       Butter Scotch                                 150"<<endl;

cout<<"Enter the SrNo. of the flavour of the icecream:::--"<<endl;cin>>j;
     switch(j)
     {
     case 1:
        cout<<"The Name Of your icecream is Vanila"<<endl;
        f<<"The Name of icecream is Vanila"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 2:
        cout<<"The Name Of your icecream is Fresh Strawberry"<<endl;
        f<<"The Name of icecream is Fresh Strawberry"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 3:
        cout<<"The Name Of your icecream is Fresh Orange"<<endl;
        f<<"The Name of icecream is Fresh Orange"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
		break;
	 
         case 4:
        cout<<"The Name Of your icecream is Mangoo Ripple"<<endl;
        f<<"The Name of icecream is Mangoo Ripple"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 5:
        cout<<"The Name Of your icecream is  Chocolate Ripple"<<endl;
        f<<"The Name of icecream is  Chocolate Ripple"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 6:
        cout<<"The Name Of your icecream is Gulab Kaaju"<<endl;
        f<<"The Name of icecream is Gulab Kaaju"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
		break;
		    case 7:
        cout<<"The Name Of your icecream is Black Current"<<endl;
        f<<"The Name of icecream is Vanila";
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 8:
        cout<<"The Name Of your icecream is American Nuts"<<endl;
        f<<"The Name of icecream is American Nuts"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
        break;
     case 9:
        cout<<"The Name Of your icecream is Butter Scotch"<<endl;
        f<<"The Name of icecream is Butter Scotch"<<endl;
		cout<<"Please enter The Quantity of the icecream"<<endl;cin>>quantity;
        f<<"The Quantity of the icecream is::"<<quantity<<endl;
		break;
		f.close();
    }}
	 void updation()
	 {
	 
	 cout<<"If you want to change your order"<<endl;
	 cout<<"Then you can change by choosing your option"<<endl;
     cout<<"Enter 1 to change icecream SrNo."<<endl;
	 cout<<"Enter 2 to change the quantity of icecream"<<endl;
	 cout<<"Enter 3 to change the flavour of icecream"<<endl;
	 cout<<"Or press 4 to continue";
     ofstream f("icecreamparlor.txt",ios::app);
	 cin>>i;
     switch(i)
     {
     case 1:
        cout<<"Please enter your new choice";cin>>icecream_name;
        f<<"The new icecream SrNo, is::"<<icecream_name;
        break;
     case 2:
        cout<<"Quantity of the icecream:-";cin>>quantity;
        f<<"New icecream quantity"<<quantity;
        break;
     case 3:
        cout<<"Flavour of the Icecream:-";cin>>flavour;
        f<<"New flavour of the Icecream is:-"<<flavour;
		break;
     
	 f.close();
	 }
     
    }
    


};
class billing: public icecream
{
	protected:
	int unit_prize;
	int bill;
	public:
	void total()
	
	{
		if(j==1||j==6||j==3)
		{
			unit_prize=110;
		}
			else if(j==2||j==7)
		{
			unit_prize=160;
		}
		  else   if(j==4||j==5)
		{
			
			unit_prize=140;
		}
		else 
		{
			unit_prize=150;
		}
		   
		ofstream f("icecreamparlor.txt",ios::app);
		bill=unit_prize*quantity;
		cout<<"Your Total Bill Is :- INC   "<<bill<<endl;
		f<<"Your Total Bill Is :- INC   "<<bill<<endl;
		cout<<"Please Pay Your Bill At The Coutnter And Get Your Order"<<endl;
		f<<"Please Pay Your Bill At The Coutnter And Get Your Order"<<endl;
		cout<<"***************************  Thanku for visiting  ************************"<<endl;
		f<<"***************************  Thanku for visiting  ************************"<<endl;
		cout<<"******************************  Visit Again  *****************************"<<endl;
		f<<"******************************  Visit Again  *****************************"<<endl;
	f.close();
	}
	
	
};


int main()
{int k;
    billing c1;
    c1.detail();
    c1.updation();
	c1.total();
	
	
}
